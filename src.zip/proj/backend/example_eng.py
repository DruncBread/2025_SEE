##############  API 1: get history budget data ############## 
http://59.65.191.49:9090/history
GET
#output:
{
    "historical": [
        {
            "cash_flows": [
                -300000,
                120000,
                150000
            ],
            "year": 2025
        },
        {
            "cash_flows": [
                -250000,
                120000,
                150000
            ],
            "year": 2024
        },
        {
            "cash_flows": [
                -200000,
                120000,
                150000
            ],
            "year": 2023
        }
    ]
}


############## API 2: full analysis ############## 
http://59.65.191.49:9090/analyze
POST

## input:
{
  "cocomo": {
    "sloc": 15000,  # Lines of source code (required, numeric type)
    "project_class": "S",  # Project class (required, optional values: O/S/E)
    "eaf": 1.1  # Environment adjustment factor (optional, default 1.0, floating point)
  },
  "discount_rate": 0.07,  # Discount rate for financial forecasting (required, floating point)
  "resource_allocation_inputs": {  # Resource allocation inputs (required)
    "tasks": [  # Task list (each task must include id/name/duration/dependencies)
      {
        "id": "T1",
        "name": "Requirement Analysis",
        "duration": 5,  # Task duration (days)
        "dependencies": []  # IDs of dependent predecessor tasks (array)
      },
      {
        "id": "T2",
        "name": "System Design",
        "duration": 8,
        "dependencies": ["T1"]
      },
      {
        "id": "T3",
        "name": "Development Implementation",
        "duration": 20,
        "dependencies": ["T2"]
      },
      {
        "id": "T4",
        "name": "Testing Verification",
        "duration": 7,
        "dependencies": ["T3"]
      }
    ],
    "resource_capacity": {  # Resource capacity (required)
      "developers": 6,  # Number of available developers
      "testers": 3  # Number of available testers
    }
  }
}


## output:
{
    "cocomo": {
        "D": 10.272607456387178, # duration
        "E": 41.21991232716921, #effort
        "P": 4.012604638322863, #people
        "cost_USD": 164879.65,
        "input_parameters": {
            "eaf": 1.0,
            "project_class": "O",
            "sloc": 15000
        }
    },
    "financial": {
        "budgetTracking": {
            "actual": [
                -164879.65,
                165000.0,
                180000.0,
                195000.0
            ],
            "planned": [
                164879.65,
                0,
                0,
                0
            ],
            "variance": [
                -329759.3,
                165000.0,
                180000.0,
                195000.0
            ]
        },
        "cashFlowAnalysis": [
            {
                "cashFlow": -164879.65,
                "period": "Period 0"
            },
            {
                "cashFlow": 165000.0,
                "period": "Period 1"
            },
            {
                "cashFlow": 180000.0,
                "period": "Period 2"
            },
            {
                "cashFlow": 195000.0,
                "period": "Period 3"
            }
        ],
        "discount_rate": 0.07,
        "irr": 90.18,
        "npv": 305723.01,
        "payback_period": 1.0,
        "roi": 127.51
    },
    "resource_schedule": {
        "criticalPath": [
            "T4"
        ],
        "optimization": {
            "current": {
                "cost": 164879.65,
                "duration": 40
            },
            "optimized": {
                "cost": 156635.66749999998,
                "duration": 36.0
            },
            "savings": {
                "cost": 8243.9825,
                "time": 4.0
            }
        },
        "projectDuration": 40,
        "resourceUtilization": [
            {
                "name": "developers",
                "utilization": 0.47
            },
            {
                "name": "testers",
                "utilization": 0.4
            }
        ],
        "totalCost": 164879.65
    },
    "risk_analysis": {
        "monteCarloResults": {
            "confidenceInterval": {
                "lower": 114559.88,
                "upper": 220179.38
            },
            "distribution": [
                {
                    "frequency": 4,
                    "value": 57995.84508259606
                },
                {
                    "frequency": 22,
                    "value": 81388.96596879902
                },
                {
                    "frequency": 96,
                    "value": 104782.086855002
                },
                {
                    "frequency": 228,
                    "value": 128175.20774120497
                },
                {
                    "frequency": 272,
                    "value": 151568.32862740793
                },
                {
                    "frequency": 226,
                    "value": 174961.4495136109
                },
                {
                    "frequency": 104,
                    "value": 198354.57039981388
                },
                {
                    "frequency": 38,
                    "value": 221747.69128601684
                },
                {
                    "frequency": 9,
                    "value": 245140.8121722198
                },
                {
                    "frequency": 1,
                    "value": 268533.93305842276
                }
            ],
            "expectedValue": 165517.14,
            "standardDeviation": 32274.41
        },
        "riskMatrix": [
            {
                "impact": 0.8,
                "name": "Technical Complexity Risk",
                "probability": 0.3,
                "score": 0.24
            },
            {
                "impact": 0.6,
                "name": "Human Resource Risk",
                "probability": 0.2,
                "score": 0.12
            },
            {
                "impact": 0.9,
                "name": "Budget Overrun Risk",
                "probability": 0.4,
                "score": 0.36
            }
        ],
        "sensitivityAnalysis": [
            {
                "impact": -2.85,
                "variable": "discount_rate"
            },
            {
                "impact": 10.0,
                "variable": "development_cost"
            },
            {
                "impact": 20.0,
                "variable": "project_scale"
            }
        ],
        "totalRiskScore": 0.72
    }
}