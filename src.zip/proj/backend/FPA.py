# 功能点默认权重（符合标准 FPA 定义）
FPA_DEFAULT_WEIGHTS = {
    'ei': 3,   # 外部输入
    'eo': 4,   # 外部输出
    'eq': 3,   # 外部查询
    'ilf': 7,  # 内部逻辑文件
    'eif': 5   # 外部接口文件
}


def get_FPA_result(data):

    # 提取可选参数（VAF、行业系数、成本费率）
    vaf = float(data.get('vaf', 1.0))  # 价值调整因子，默认 1.0
    # 功能点转工作量系数，默认 2 人月/FP
    industry_coeff = float(data.get('industry_coeff', 2.0))
    cost_per_person_month = float(data.get('cost_per_person_month', 4000.0))  # 每人月成本，默认 4000 美元
    
    if 'weight' not in data.keys():
        data['weight']={}
    for field in ['ei', 'eo', 'eq', 'ilf', 'eif']:
        if  (field not in data['weight']) or data['weight'][field]==None:
            data['weight'][field]=FPA_DEFAULT_WEIGHTS[field]

    # 计算原始功能点
    raw_function_points = sum(
        data[field] * data['weight'][field]
        for field in ['ei', 'eo', 'eq', 'ilf', 'eif']
    )

    # 计算等效功能点（调整后）
    adjusted_function_points = raw_function_points * vaf

    # 转换为工作量（人月）和成本（美元）
    effort = adjusted_function_points * industry_coeff
    cost = effort * cost_per_person_month

    return {
        "calculation_result": {
            "raw_function_points": raw_function_points,          # 原始功能点
            # 等效功能点
            "adjusted_function_points": round(adjusted_function_points, 2),
            "effort": round(effort, 2),                          # 工作量（人月）
            "cost": round(cost, 2),                              # 成本（美元）
            "units": {
                "function_points": "FP",
                "effort": "person-months",
                "cost": "USD"
            }
        }
    }
