{
  "cocomo": {
    "sloc": 15000,  # 源代码行数（必填，数字类型）
    "project_class": "S",  # 项目类型（必填，可选值：O/S/E）
    "eaf": 1.1  # 环境调整因子（可选，默认1.0，浮点数）
  },
  "discount_rate": 0.07,  # 财务预测折现率（必填，浮点数）
  "resource_allocation_inputs": {  # 资源分配输入（必填）
    "tasks": [  # 任务列表（每个任务需包含id/name/duration/dependencies）
      {
        "id": "T1",
        "name": "需求分析",
        "duration": 5,  # 任务持续时间（天）
        "dependencies": []  # 依赖的前置任务id（数组）
      },
      {
        "id": "T2",
        "name": "系统设计",
        "duration": 8,
        "dependencies": ["T1"]
      },
      {
        "id": "T3",
        "name": "开发实现",
        "duration": 20,
        "dependencies": ["T2"]
      },
      {
        "id": "T4",
        "name": "测试验证",
        "duration": 7,
        "dependencies": ["T3"]
      }
    ],
    "resource_capacity": {  # 资源容量（必填）
      "developers": 6,  # 可用开发人员数量
      "testers": 3  # 可用测试人员数量
    }
  }
}