import numpy as np
import numpy_financial as npf
import random
import pandas as pd
from datetime import datetime, timedelta
from scipy.stats import norm
from sklearn.linear_model import LinearRegression


def get_mock_task_data():
    return {

        "tasks": [
            {
                "id": "T1",
                "name": "需求分析",
                "duration": 5,  # 持续5天
                "dependencies": []  # 无前置任务
            },
            {
                "id": "T2",
                "name": "系统设计",
                "duration": 7,
                "dependencies": ["T1"]  # 依赖需求分析（T1）
            },
            {
                "id": "T3",
                "name": "开发实现",
                "duration": 15,
                "dependencies": ["T2"]  # 依赖系统设计（T2）
            },
            {
                "id": "T4",
                "name": "测试验证",
                "duration": 6,
                "dependencies": ["T3"]  # 依赖开发实现（T3）
            }
        ],
        "resource_capacity": {
            "developers": 5,  # 可用开发人员5人
            "testers": 2      # 可用测试人员2人
        }

    }


def calculate_resource_allocation(tasks, resource_capacity):
    """
    简化版资源分配计算（包含资源平衡和资源平滑逻辑）
    :param tasks: 任务列表（格式见data_process.py的resource_allocation_inputs.tasks）
    :param resource_capacity: 资源容量（如developers:5, testers:2）
    :return: 资源分配分析结果
    """
    # 关键路径计算（简化版）
    print(tasks)
    task_map = {t['id']: t for t in tasks}
    print(task_map)
    for task in tasks:
        task['earliest_start'] = max(
            [task_map[d]['earliest_end'] for d in task['dependencies']], default=0)
        task['earliest_end'] = task['earliest_start'] + task['duration']
    critical_path = [t['id'] for t in tasks if t['earliest_end']
                     == max(t['earliest_end'] for t in tasks)]
    project_duration = max(t['earliest_end'] for t in tasks)

    # 资源利用率模拟（假设所有任务都使用developers资源）
    resource_utilization = [{
        "name": "developers",
        # 简化计算
        "utilization": round(len(tasks) * 0.7 / resource_capacity['developers'], 2)
    }, {
        "name": "testers",
        "utilization": round(len(tasks) * 0.3 / resource_capacity['testers'], 2)
    }]

    # 优化模拟（假设优化后工期缩短10%，成本降低5%）
    return {
        "totalCost": 0,  # 后续从COCOMO结果填充
        "projectDuration": project_duration,
        "resourceUtilization": resource_utilization,
        "criticalPath": critical_path,
        "optimization": {
            "current": {"cost": 0, "duration": project_duration},  # 后续填充
            "optimized": {"cost": 0, "duration": project_duration * 0.9},
            "savings": {"cost": 0, "time": project_duration * 0.1}
        }
    }
