

import math

from io import BytesIO
import os
import base64
import numpy as np

import json

import numpy_financial as npf

def predict_project_viability(cocomo_output, historical_data,discount_rate):
    """综合历史数据和新项目参数进行预测"""
    # COCOMO计算开发成本
    dev_cost = cocomo_output['cost_USD']
    
    # 基于历史数据生成现金流预测
    avg_growth = np.mean([year['cash_flows'][-1] for year in historical_data])
    predicted_cashflows = [-dev_cost] + [
        avg_growth * (1 + 0.1*i) for i in range(1,4)
    ]
    print('here',discount_rate)
    
    return calculate_financial_metrics(
        cash_flows=predicted_cashflows,
        discount_rate=discount_rate  # 使用历史平均折现率
    )

def calculate_financial_metrics(cash_flows, discount_rate=0.05, development_cost=None):
    """
    计算财务指标：ROI、NPV、IRR、投资回收期
    :param cash_flows: 现金流列表（第0期为初始投资，后续为正收益）
    :param discount_rate: 折现率（默认5%）
    :return: 指标字典
    """

    if not cash_flows:
        raise ValueError("现金流数据为空")
    
    initial_investment = -cash_flows[0]  # 初始投资为负数（假设输入为正数，转为负数计算）
    total_return = sum(cash_flows) - initial_investment
    roi = (total_return / initial_investment) * 100 if initial_investment != 0 else 0
    
    # 计算NPV
    npv = 0
    for t, cf in enumerate(cash_flows):
        npv += cf / (1 + discount_rate) ** t
    
    # 计算IRR（使用numpy近似）
    try:
        irr = npf.irr(cash_flows) * 100
    except ValueError:
        irr = 0.0
    
    # 计算投资回收期（静态）
    cumulative = 0
    payback_period = -1
    for t, cf in enumerate(cash_flows):
        cumulative += cf
        if cumulative >= 0 and payback_period == -1:
            payback_period = t
            if cumulative > 0:
                # 插值计算小数部分
                overshoot = cumulative - 0
                previous = cumulative - cf
                payback_period += overshoot / cf  # 假设现金流均匀分布
                break
    
    # 生成现金流分析数据
    cash_flow_analysis = [
        {"period": f"Period {i}", "cashFlow": cf}
        for i, cf in enumerate(cash_flows)
    ]
    
    # 生成预算跟踪数据（示例数据，需根据实际业务逻辑调整）
    # 使用COCOMO计算值作为计划预算（如果存在）
    planned = [-cash_flows[0]] 
    if development_cost:
        planned += [-development_cost]  # 新增开发阶段预算
    else:
        planned += [0] * (len(cash_flows)-1)
    
    return {
        "roi": round(roi, 2),
        "npv": round(npv, 2),
        "irr": round(irr, 2),
        "payback_period": round(payback_period, 2) if payback_period != -1 else "N/A",
        "cashFlowAnalysis": cash_flow_analysis,
        "budgetTracking": {
            "planned": planned,
            "actual": cash_flows,
            "variance": [a - p for a, p in zip(cash_flows, planned)]
        }
    }
    
    
def get_history_budget(historical_years=3):
    """生成带时间维度的历史数据"""
    base_year = 2025
    return {
        "historical": [
            {
                "year": base_year - i,
                # "phases": [
                #     {"name": "设计", "budget": 80000, "actual": 75000},
                #     {"name": "开发", "budget": 200000, "actual": 220000}
                # ],
                "cash_flows": [-300000 + i*50000, 120000, 150000]
            } for i in range(historical_years)
        ]
    }