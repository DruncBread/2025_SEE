import numpy as np
import numpy_financial as npf
import math
from budget import calculate_financial_metrics

def calculate_risk_analysis(cocomo_output):
        # 预定义风险清单（示例）
        # risks = [
        #     {"name": "技术复杂性风险", "base_prob": 0.3, "impact_factor": 0.8},
        #     {"name": "人力资源风险", "base_prob": 0.2, "impact_factor": 0.6},
        #     {"name": "预算超支风险", "base_prob": 0.4, "impact_factor": 0.9}
        # ]
        risks = [
            {"name": "Technical Complexity Risk", "base_prob": 0.3, "impact_factor": 0.8},
            {"name": "Human Resource Risk", "base_prob": 0.2, "impact_factor": 0.6},
            {"name": "Budget Overrun Risk", "base_prob": 0.4, "impact_factor": 0.9}
        ]
        
        # 根据COCOMO结果调整风险概率
        complexity_factor = 1.2 if cocomo_output['input_parameters']['project_class'] in ['S','E'] else 1.0
        risk_matrix = []
        total_score = 0
        
        for risk in risks:
            adj_prob = risk['base_prob'] * complexity_factor
            score = adj_prob * risk['impact_factor']
            risk_matrix.append({
                "name": risk['name'],
                "probability": round(adj_prob, 2),
                "impact": risk['impact_factor'],
                "score": round(score, 2)
            })
            total_score += score
            
        return {
            "totalRiskScore": round(total_score, 2),
            "riskMatrix": risk_matrix
        }


def monte_carlo_simulation(cashFlowAnalysis, iterations=1000):
    """蒙特卡洛模拟实现"""
    np.random.seed(42)
    simulations = []
    
    # 从 cashFlowAnalysis 中提取初始现金流（第0期）
    base_cost = -cashFlowAnalysis[0]['cashFlow']  # 修正：使用预测的cashFlow数据
    sim_results = base_cost * np.random.normal(1, 0.2, iterations)
    
    expected = np.mean(sim_results)
    std_dev = np.std(sim_results)
    
    # 生成分布直方图数据
    hist, bins = np.histogram(sim_results, bins=10)
    distribution = [{"value": float(bins[i]), "frequency": int(hist[i])} 
                   for i in range(len(hist))]
    
    return {
        "expectedValue": round(expected, 2),
        "standardDeviation": round(std_dev, 2),
        "confidenceInterval": {
            "lower": round(np.percentile(sim_results, 5), 2),
            "upper": round(np.percentile(sim_results, 95), 2)
        },
        "distribution": distribution
    }


def perform_sensitivity_analysis(financial_prediction):

    base_npv = financial_prediction['npv']
    variables = [
        {'name': 'discount_rate', 'delta': 0.01},
        {'name': 'development_cost', 'delta': 0.1},
        {'name': 'project_scale', 'delta': 0.2}
    ]

    sensitivity = []
    # 从 cashFlowAnalysis 提取原始现金流数组（修正关键）
    original_cash_flows = [item['cashFlow'] for item in financial_prediction['cashFlowAnalysis']]

    for var in variables:
        modified = financial_prediction.copy()
        if var['name'] == 'discount_rate':
            # 使用原始现金流数组计算新 NPV
            new_npv = calculate_financial_metrics(
                original_cash_flows,  # 修正：从 cashFlowAnalysis 提取的现金流数组
                modified['discount_rate'] + var['delta']  # 调整折现率
            )['npv']
        else:
            # 其他变量影响的示例逻辑（保持原逻辑）
            new_npv = base_npv * (1 + var['delta'])
            
        impact = ((new_npv - base_npv) / base_npv) * 100 if base_npv != 0 else 0
        sensitivity.append({
            "variable": var['name'],
            "impact": round(impact, 2)
        })

    return sensitivity