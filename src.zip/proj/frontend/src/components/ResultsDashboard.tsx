import React, { useEffect, useState } from 'react';
import { Download, TrendingUp, DollarSign, AlertTriangle, Users, BarChart3, Calculator } from 'lucide-react';
import Chart from './common/Chart';
import type { AnalysisResults, ProjectData } from '../App';

interface ResultsDashboardProps {
  results: AnalysisResults;
  projectData: ProjectData;
}

interface HistoricalEntry {
  year: number;
  cash_flows: number[];
}

const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ results, projectData }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [history, setHistory] = useState<HistoricalEntry[]>([]);

  useEffect(() => {
    fetch('http://59.65.191.49:9090/history')
      .then(res => res.json())
      .then(data => setHistory(data.historical))
      .catch(err => console.error('Failed to load history:', err));
  }, []);

  const tabs = [
    { id: 'overview', name: 'Overview', icon: BarChart3 },
    { id: 'cocomo', name: 'COCOMO Analysis', icon: Calculator },
    { id: 'financial', name: 'Financial', icon: DollarSign },
    { id: 'risk', name: 'Risk Analysis', icon: AlertTriangle },
    { id: 'resources', name: 'Resources', icon: Users },
    { id: 'history', name: 'History', icon: BarChart3 }
  ];

  const exportReport = () => {
    const reportData = {
      project: projectData.projectName,
      timestamp: new Date().toISOString(),
      results: results
    };
    
    const dataStr = JSON.stringify(reportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${projectData.projectName.replace(/\s+/g, '_')}_analysis_report.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Estimated Effort</p>
              <p className="text-2xl font-bold text-white">{results.cocomo.E.toFixed(1)} PM</p>
            </div>
            <Calculator className="h-8 w-8 text-blue-400" />
          </div>
        </div>
        
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Project Cost</p>
              <p className="text-2xl font-bold text-white">${results.cocomo.cost_USD.toLocaleString()}</p>
            </div>
            <DollarSign className="h-8 w-8 text-green-400" />
          </div>
        </div>
        
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Duration</p>
              <p className="text-2xl font-bold text-white">{results.cocomo.D.toFixed(1)} months</p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-400" />
          </div>
        </div>
        
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Risk Score</p>
              <p className="text-2xl font-bold text-white">{results.risk_analysis.totalRiskScore.toFixed(1)}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-red-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Cash Flow Analysis</h3>
          <Chart 
            type="line" 
            data={{
              labels: results.financial.cashFlowAnalysis.map(c => c.period),
              datasets: [{
                label: 'Net Cash Flow',
                data: results.financial.cashFlowAnalysis.map(c => c.cashFlow),
                borderColor: 'rgb(16, 185, 129)',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4
              }]
            }} 
          />
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Resource Utilization</h3>
          <Chart 
            type="bar" 
            data={{
              labels: results.resource_schedule.resourceUtilization.map(r => r.name),
              datasets: [{
                label: 'Utilization (%)',
                data: results.resource_schedule.resourceUtilization.map(r => r.utilization),
                backgroundColor: results.resource_schedule.resourceUtilization.map(r => 
                  r.utilization > 90 ? 'rgba(239, 68, 68, 0.8)' :
                  r.utilization > 70 ? 'rgba(34, 197, 94, 0.8)' : 'rgba(245, 158, 11, 0.8)'
                )
              }]
            }} 
          />
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">Project Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-medium text-gray-300 mb-2">COCOMO Results</h4>
            <ul className="space-y-1 text-sm text-gray-400">
              <li>Effort: {results.cocomo.E.toFixed(1)} person-months</li>
              <li>Duration: {results.cocomo.D.toFixed(1)} months</li>
              <li>Team Size: {results.cocomo.P.toFixed(1)} people</li>
              <li>Cost: ${results.cocomo.cost_USD.toLocaleString()}</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-300 mb-2">Financial Metrics</h4>
            <ul className="space-y-1 text-sm text-gray-400">
              <li>ROI: {results.financial.roi.toFixed(1)}%</li>
              <li>NPV: ${results.financial.npv.toLocaleString()}</li>
              <li>IRR: {(results.financial.irr).toFixed(1)}%</li>
              <li>Payback: {results.financial.payback_period.toFixed(1)} years</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-300 mb-2">Resource Planning</h4>
            <ul className="space-y-1 text-sm text-gray-400">
              <li>Total Cost: ${results.resource_schedule.totalCost.toLocaleString()}</li>
              <li>Duration: {results.resource_schedule.projectDuration} months</li>
              <li>Cost Savings: ${results.resource_schedule.optimization.savings.cost.toLocaleString()}</li>
              <li>Time Savings: {results.resource_schedule.optimization.savings.time} months</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCocomoAnalysis = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 p-6 rounded-lg">
          <h4 className="font-medium text-white mb-2">Effort (E)</h4>
          <p className="text-2xl font-bold text-blue-400">{results.cocomo.E.toFixed(1)} PM</p>
          <p className="text-sm text-gray-400">Person-Months</p>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h4 className="font-medium text-white mb-2">Duration (D)</h4>
          <p className="text-2xl font-bold text-green-400">{results.cocomo.D.toFixed(1)} months</p>
          <p className="text-sm text-gray-400">Development Time</p>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h4 className="font-medium text-white mb-2">Team Size (P)</h4>
          <p className="text-2xl font-bold text-yellow-400">{results.cocomo.P.toFixed(1)} people</p>
          <p className="text-sm text-gray-400">Average Team Size</p>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h4 className="font-medium text-white mb-2">Total Cost</h4>
          <p className="text-2xl font-bold text-purple-400">${results.cocomo.cost_USD.toLocaleString()}</p>
          <p className="text-sm text-gray-400">USD</p>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">Input Parameters</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">SLOC</h4>
            <p className="text-2xl font-bold text-blue-400">
              {results.cocomo.input_parameters.sloc.toLocaleString()}
            </p>
            <p className="text-sm text-gray-400">Source Lines of Code</p>
          </div>
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">Project Class</h4>
            <p className="text-2xl font-bold text-green-400">
              {results.cocomo.input_parameters.project_class}
            </p>
            <p className="text-sm text-gray-400">
              {results.cocomo.input_parameters.project_class === 'O' ? 'Organic' :
               results.cocomo.input_parameters.project_class === 'S' ? 'Semi-detached' : 'Embedded'}
            </p>
          </div>
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">EAF</h4>
            <p className="text-2xl font-bold text-yellow-400">
              {results.cocomo.input_parameters.eaf.toFixed(2)}
            </p>
            <p className="text-sm text-gray-400">Effort Adjustment Factor</p>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">COCOMO Model Visualization</h3>
        <Chart 
          type="bar" 
          data={{
            labels: ['Effort (PM)', 'Duration (months)', 'Team Size', 'Cost (thousands USD)'],
            datasets: [{
              label: 'COCOMO Results',
              data: [
                results.cocomo.E,
                results.cocomo.D,
                results.cocomo.P,
                results.cocomo.cost_USD / 1000
              ],
              backgroundColor: [
                'rgba(59, 130, 246, 0.8)',
                'rgba(16, 185, 129, 0.8)',
                'rgba(245, 158, 11, 0.8)',
                'rgba(168, 85, 247, 0.8)'
              ]
            }]
          }} 
        />
      </div>
    </div>
  );

  const renderFinancialAnalysis = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">ROI</p>
              <p className="text-2xl font-bold text-white">{results.financial.roi.toFixed(1)}%</p>
            </div>
            <TrendingUp className={`h-8 w-8 ${results.financial.roi > 0 ? 'text-green-400' : 'text-red-400'}`} />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">NPV</p>
              <p className="text-2xl font-bold text-white">${results.financial.npv.toLocaleString()}</p>
            </div>
            <DollarSign className={`h-8 w-8 ${results.financial.npv > 0 ? 'text-green-400' : 'text-red-400'}`} />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">IRR</p>
              <p className="text-2xl font-bold text-white">{(results.financial.irr).toFixed(1)}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-blue-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Payback Period</p>
              <p className="text-2xl font-bold text-white">{results.financial.payback_period.toFixed(1)} years</p>
            </div>
            <BarChart3 className="h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Cash Flow Analysis</h3>
          <Chart 
            type="line" 
            data={{
              labels: results.financial.cashFlowAnalysis.map(c => c.period),
              datasets: [{
                label: 'Net Cash Flow',
                data: results.financial.cashFlowAnalysis.map(c => c.cashFlow),
                borderColor: 'rgb(16, 185, 129)',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4
              }]
            }} 
          />
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Budget Tracking</h3>
          <Chart 
            type="line" 
            data={{
              labels: ['Q1', 'Q2', 'Q3', 'Q4', 'Q5'],
              datasets: [
                {
                  label: 'Planned',
                  data: results.financial.budgetTracking.planned,
                  borderColor: 'rgb(59, 130, 246)',
                  backgroundColor: 'rgba(59, 130, 246, 0.1)',
                  tension: 0.4
                },
                {
                  label: 'Actual',
                  data: results.financial.budgetTracking.actual,
                  borderColor: 'rgb(16, 185, 129)',
                  backgroundColor: 'rgba(16, 185, 129, 0.1)',
                  tension: 0.4
                }
              ]
            }} 
          />
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">Budget Variance Analysis</h3>
        <Chart 
          type="bar" 
          data={{
            labels: ['Q1', 'Q2', 'Q3', 'Q4', 'Q5'],
            datasets: [{
              label: 'Variance (%)',
              data: results.financial.budgetTracking.variance,
              backgroundColor: results.financial.budgetTracking.variance.map(v => 
                v > 0 ? 'rgba(239, 68, 68, 0.8)' : 'rgba(16, 185, 129, 0.8)'
              )
            }]
          }} 
        />
      </div>
    </div>
  );

  const renderRiskAnalysis = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Total Risk Score</p>
              <p className="text-2xl font-bold text-white">{results.risk_analysis.totalRiskScore.toFixed(1)}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-red-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">High Risk Items</p>
              <p className="text-2xl font-bold text-white">{results.risk_analysis.riskMatrix.filter(r => r.score > 6).length}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-red-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Expected Value</p>
              <p className="text-2xl font-bold text-white">${results.risk_analysis.monteCarloResults.expectedValue.toLocaleString()}</p>
            </div>
            <DollarSign className="h-8 w-8 text-blue-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Std Deviation</p>
              <p className="text-2xl font-bold text-white">${results.risk_analysis.monteCarloResults.standardDeviation.toLocaleString()}</p>
            </div>
            <BarChart3 className="h-8 w-8 text-yellow-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Risk Matrix</h3>
          <Chart 
            type="bubble" 
            data={{
              datasets: [{
                label: 'Risk Assessment',
                data: results.risk_analysis.riskMatrix.map(risk => ({
                  x: risk.probability,
                  y: risk.impact,
                  r: 15,
                  label: risk.name
                })),
                backgroundColor: results.risk_analysis.riskMatrix.map(risk => {
                  if (risk.score > 6) return 'rgba(239, 68, 68, 0.8)';
                  if (risk.score > 3) return 'rgba(245, 158, 11, 0.8)';
                  return 'rgba(34, 197, 94, 0.8)';
                })
              }]
            }} 
          />
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Sensitivity Analysis</h3>
          <Chart 
            type="bar" 
            data={{
              labels: results.risk_analysis.sensitivityAnalysis.map(s => s.variable),
              datasets: [{
                label: 'Impact (%)',
                data: results.risk_analysis.sensitivityAnalysis.map(s => s.impact),
                backgroundColor: 'rgba(168, 85, 247, 0.8)'
              }]
            }} 
          />
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">Monte Carlo Simulation Results</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">Expected Value</h4>
            <p className="text-2xl font-bold text-blue-400">
              ${results.risk_analysis.monteCarloResults.expectedValue.toLocaleString()}
            </p>
          </div>
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">95% Confidence Interval</h4>
            <p className="text-2xl font-bold text-green-400">
              ${results.risk_analysis.monteCarloResults.confidenceInterval.lower.toLocaleString()} - 
              ${results.risk_analysis.monteCarloResults.confidenceInterval.upper.toLocaleString()}
            </p>
          </div>
          <div className="bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">Standard Deviation</h4>
            <p className="text-2xl font-bold text-yellow-400">
              ${results.risk_analysis.monteCarloResults.standardDeviation.toLocaleString()}
            </p>
          </div>
        </div>
        <Chart 
          type="bar" 
          data={{
            labels: results.risk_analysis.monteCarloResults.distribution.map((_, i) => `${i}k`),
            datasets: [{
              label: 'Frequency',
              data: results.risk_analysis.monteCarloResults.distribution.map(d => d.frequency),
              backgroundColor: 'rgba(59, 130, 246, 0.8)'
            }]
          }} 
        />
      </div>
    </div>
  );

  const renderResourceAnalysis = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Total Cost</p>
              <p className="text-2xl font-bold text-white">${results.resource_schedule.totalCost.toLocaleString()}</p>
            </div>
            <DollarSign className="h-8 w-8 text-green-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Duration</p>
              <p className="text-2xl font-bold text-white">{results.resource_schedule.projectDuration} months</p>
            </div>
            <BarChart3 className="h-8 w-8 text-blue-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Cost Savings</p>
              <p className="text-2xl font-bold text-white">${results.resource_schedule.optimization.savings.cost.toLocaleString()}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-400" />
          </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">Time Savings</p>
              <p className="text-2xl font-bold text-white">{results.resource_schedule.optimization.savings.time} months</p>
            </div>
            <Users className="h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Resource Utilization</h3>
          <Chart 
            type="bar" 
            data={{
              labels: results.resource_schedule.resourceUtilization.map(r => r.name),
              datasets: [{
                label: 'Utilization (%)',
                data: results.resource_schedule.resourceUtilization.map(r => r.utilization),
                backgroundColor: results.resource_schedule.resourceUtilization.map(r => 
                  r.utilization > 90 ? 'rgba(239, 68, 68, 0.8)' :
                  r.utilization > 70 ? 'rgba(34, 197, 94, 0.8)' : 'rgba(245, 158, 11, 0.8)'
                )
              }]
            }} 
          />
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 text-white">Critical Path</h3>
          <div className="space-y-3">
            {results.resource_schedule.criticalPath.map((task, index) => (
              <div key={index} className="flex items-center p-3 bg-gray-700 rounded-lg">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">
                  {index + 1}
                </div>
                <span className="text-white">{task}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">Optimization Comparison</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-gray-400 border-b border-gray-700">
                <th className="pb-2">Scenario</th>
                <th className="pb-2">Total Cost</th>
                <th className="pb-2">Duration</th>
                <th className="pb-2">Efficiency</th>
                <th className="pb-2">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-700">
                <td className="py-2 text-white">Current Plan</td>
                <td className="py-2 text-white">${results.resource_schedule.optimization.current.cost.toLocaleString()}</td>
                <td className="py-2 text-white">{results.resource_schedule.optimization.current.duration} months</td>
                <td className="py-2 text-white">Standard</td>
                <td className="py-2">
                  <span className="px-2 py-1 bg-yellow-600 text-white rounded text-xs">Current</span>
                </td>
              </tr>
              <tr className="border-b border-gray-700">
                <td className="py-2 text-white">Optimized Plan</td>
                <td className="py-2 text-white">${results.resource_schedule.optimization.optimized.cost.toLocaleString()}</td>
                <td className="py-2 text-white">{results.resource_schedule.optimization.optimized.duration} months</td>
                <td className="py-2 text-white">High</td>
                <td className="py-2">
                  <span className="px-2 py-1 bg-green-600 text-white rounded text-xs">Recommended</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderHistoryAnalysis = () => {
    if (history.length === 0) {
      return (
        <div className="text-white text-center py-10">
          Loading historical data or no data available.
        </div>
      );
    }

    return (
      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4 text-white">Historical Cash Flow Comparison</h3>
        <Chart
          type="bar"
          data={{
            labels: history.map(entry => entry.year.toString()),
            datasets: history[0].cash_flows.map((_, i) => ({
              label: `Year ${i + 1}`,
              data: history.map(entry => entry.cash_flows[i]),
              backgroundColor: `rgba(${100 + i * 40}, ${180 - i * 30}, ${255 - i * 50}, 0.8)`
            }))
          }}
        />
      </div>
    );
  };



  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return renderOverview();
      case 'cocomo':
        return renderCocomoAnalysis();
      case 'financial':
        return renderFinancialAnalysis();
      case 'risk':
        return renderRiskAnalysis();
      case 'resources':
        return renderResourceAnalysis();
      case 'history':
        return renderHistoryAnalysis();
      default:
        return renderOverview();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-white">Project : {projectData.projectName} - Analysis Results</h2>
          <p className="text-gray-400 mt-1">Comprehensive project analysis and recommendations</p>
        </div>
        <button
          onClick={exportReport}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </button>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4 mr-2" />
              {tab.name}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {renderTabContent()}
    </div>
  );
};

export default ResultsDashboard;