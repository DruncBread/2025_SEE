import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line, Bar, Doughnut, Radar, Bubble } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface ChartProps {
  type: 'line' | 'bar' | 'doughnut' | 'radar' | 'bubble';
  data: any;
  options?: any;
}

const Chart: React.FC<ChartProps> = ({ type, data, options = {} }) => {
  const defaultOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: '#ffffff',
        },
      },
    },
    scales: type !== 'doughnut' && type !== 'radar' ? {
      x: {
        ticks: {
          color: '#9CA3AF',
        },
        grid: {
          color: 'rgba(156, 163, 175, 0.1)',
        },
      },
      y: {
        ticks: {
          color: '#9CA3AF',
        },
        grid: {
          color: 'rgba(156, 163, 175, 0.1)',
        },
      },
    } : type === 'radar' ? {
      r: {
        ticks: {
          color: '#9CA3AF',
        },
        grid: {
          color: 'rgba(156, 163, 175, 0.3)',
        },
        pointLabels: {
          color: '#ffffff',
        },
      },
    } : {},
  };

  const mergedOptions = { ...defaultOptions, ...options };

  const chartStyle = { height: '300px' };

  switch (type) {
    case 'line':
      return <div style={chartStyle}><Line data={data} options={mergedOptions} /></div>;
    case 'bar':
      return <div style={chartStyle}><Bar data={data} options={mergedOptions} /></div>;
    case 'doughnut':
      return <div style={chartStyle}><Doughnut data={data} options={mergedOptions} /></div>;
    case 'radar':
      return <div style={chartStyle}><Radar data={data} options={mergedOptions} /></div>;
    case 'bubble':
      return <div style={chartStyle}><Bubble data={data} options={mergedOptions} /></div>;
    default:
      return <div style={chartStyle}><Line data={data} options={mergedOptions} /></div>;
  }
};

export default Chart;