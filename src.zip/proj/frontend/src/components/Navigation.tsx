import React from 'react';
import { BarChart3, ArrowLeft, CheckCircle } from 'lucide-react';

interface NavigationProps {
  currentStep: 'input' | 'results';
  onBackToInput: () => void;
  projectName?: string;
}

const Navigation: React.FC<NavigationProps> = ({ currentStep, onBackToInput, projectName }) => {
  return (
    <nav className="bg-gray-800 shadow-lg border-b border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            {/* <BarChart3 className="h-8 w-8 text-blue-400 mr-3" /> */}
            <div>
              <h1 className="text-xl font-bold text-white">Software economics</h1>
              {projectName && (
                <p className="text-sm text-gray-400">Project : {projectName}</p>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            {/* Progress Indicator */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full ${currentStep === 'input' ? 'bg-blue-500' : 'bg-green-500'} mr-2`}></div>
                <span className={`text-sm ${currentStep === 'input' ? 'text-blue-400' : 'text-green-400'}`}>
                  Data Collection
                </span>
                {currentStep === 'results' && <CheckCircle className="h-4 w-4 text-green-400 ml-1" />}
              </div>
              
              <div className={`w-8 h-0.5 ${currentStep === 'results' ? 'bg-green-500' : 'bg-gray-600'}`}></div>
              
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full ${currentStep === 'results' ? 'bg-blue-500' : 'bg-gray-600'} mr-2`}></div>
                <span className={`text-sm ${currentStep === 'results' ? 'text-blue-400' : 'text-gray-400'}`}>
                  Analysis Results
                </span>
              </div>
            </div>
            
            {currentStep === 'results' && (
              <button
                onClick={onBackToInput}
                className="flex items-center px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Input
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;