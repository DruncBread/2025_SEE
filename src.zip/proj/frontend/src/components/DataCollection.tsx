import React, { useState } from 'react';
import { Plus, Minus, Calculator, DollarSign, Users, Settings } from 'lucide-react';
import type { ProjectData } from '../App';

interface DataCollectionProps {
  onSubmit: (data: ProjectData) => void;
}

const DataCollection: React.FC<DataCollectionProps> = ({ onSubmit }) => {
  const [activeSection, setActiveSection] = useState(0);
  const [formData, setFormData] = useState<ProjectData>({
    projectName: '',
    cocomo: {
      sloc: 15000,
      project_class: 'S',
      eaf: 1.1
    },
    discount_rate: 0.07,
    resource_allocation_inputs: {
      tasks: [
        { id: '1', name: 'Requirements Analysis', duration: 5, dependencies: [] },
        { id: '2', name: 'System Design', duration: 8, dependencies: ['1'] },
        { id: '3', name: 'Development Implementation', duration: 20, dependencies: ['2'] },
        { id: '4', name: 'Testing Verification', duration: 7, dependencies: ['3'] }
      ],
      resource_capacity: {
        developers: 6,
        testers: 3
      }
    }
  });

  const sections = [
    { id: 0, title: 'Project Overview', icon: Calculator },
    { id: 1, title: 'COCOMO Parameters', icon: Settings },
    { id: 2, title: 'Financial Settings', icon: DollarSign },
    { id: 3, title: 'Resource Planning', icon: Users }
  ];

  const handleInputChange = (field: string, value: any) => {
    if (field.includes('.')) {
      const keys = field.split('.');
      setFormData(prev => {
        const updated = { ...prev };
        let current: any = updated;
        
        for (let i = 0; i < keys.length - 1; i++) {
          current = current[keys[i]];
        }
        current[keys[keys.length - 1]] = value;
        
        return updated;
      });
    } else {
      setFormData(prev => ({ ...prev, [field]: value }));
    }
  };

  const handleTaskChange = (index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      resource_allocation_inputs: {
        ...prev.resource_allocation_inputs,
        tasks: prev.resource_allocation_inputs.tasks.map((task, i) => 
          i === index ? { ...task, [field]: value } : task
        )
      }
    }));
  };

  const addTask = () => {
    const newTask = {
      id: Date.now().toString(),
      name: 'New Task',
      duration: 5,
      dependencies: []
    };
    
    setFormData(prev => ({
      ...prev,
      resource_allocation_inputs: {
        ...prev.resource_allocation_inputs,
        tasks: [...prev.resource_allocation_inputs.tasks, newTask]
      }
    }));
  };

  const removeTask = (index: number) => {
    setFormData(prev => ({
      ...prev,
      resource_allocation_inputs: {
        ...prev.resource_allocation_inputs,
        tasks: prev.resource_allocation_inputs.tasks.filter((_, i) => i !== index)
      }
    }));
  };

  const handleSubmit = () => {
    onSubmit(formData);
  };

  const renderSection = () => {
    switch (activeSection) {
      case 0:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">Project Overview</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Project Name</label>
              <input
                type="text"
                value={formData.projectName}
                onChange={(e) => handleInputChange('projectName', e.target.value)}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                placeholder="Enter project name"
              />
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">COCOMO Parameters</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  SLOC (Source Lines of Code)
                </label>
                <input
                  type="number"
                  value={formData.cocomo.sloc}
                  onChange={(e) => handleInputChange('cocomo.sloc', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Project Class
                </label>
                <select
                  value={formData.cocomo.project_class}
                  onChange={(e) => handleInputChange('cocomo.project_class', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                >
                  <option value="O">Organic (O)</option>
                  <option value="S">Semi-detached (S)</option>
                  <option value="E">Embedded (E)</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  EAF (Effort Adjustment Factor)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.cocomo.eaf || 1.0}
                  onChange={(e) => handleInputChange('cocomo.eaf', parseFloat(e.target.value) || 1.0)}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                />
              </div>
            </div>

            <div className="bg-gray-800 p-4 rounded-lg">
              <h4 className="text-lg font-semibold text-white mb-2">Project Class Descriptions</h4>
              <div className="space-y-2 text-sm text-gray-300">
                <p><strong>Organic (O):</strong> Small teams, familiar environment, flexible requirements</p>
                <p><strong>Semi-detached (S):</strong> Medium teams, mixed experience, medium complexity</p>
                <p><strong>Embedded (E):</strong> Large teams, complex systems, tight constraints</p>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">Financial Settings</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Discount Rate (%)
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.discount_rate}
                onChange={(e) => handleInputChange('discount_rate', (parseFloat(e.target.value) || 0) / 100)}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
              />
              <p className="text-sm text-gray-400 mt-1">
                Used for NPV and financial calculations
              </p>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">Resource Planning</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Number of Developers
                </label>
                <input
                  type="number"
                  value={formData.resource_allocation_inputs.resource_capacity.developers}
                  onChange={(e) => handleInputChange('resource_allocation_inputs.resource_capacity.developers', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Number of Testers
                </label>
                <input
                  type="number"
                  value={formData.resource_allocation_inputs.resource_capacity.testers}
                  onChange={(e) => handleInputChange('resource_allocation_inputs.resource_capacity.testers', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                />
              </div>
            </div>

            <div className="bg-gray-800 p-6 rounded-lg">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-lg font-semibold text-white">Project Tasks</h4>
                <button
                  onClick={addTask}
                  className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Task
                </button>
              </div>
              
              {formData.resource_allocation_inputs.tasks.map((task, index) => (
                <div key={task.id} className="bg-gray-700 p-4 rounded-lg mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">Task Name</label>
                      <input
                        type="text"
                        value={task.name}
                        onChange={(e) => handleTaskChange(index, 'name', e.target.value)}
                        className="w-full px-2 py-1 bg-gray-600 border border-gray-500 rounded text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">Duration (days)</label>
                      <input
                        type="number"
                        value={task.duration}
                        onChange={(e) => handleTaskChange(index, 'duration', parseInt(e.target.value) || 0)}
                        className="w-full px-2 py-1 bg-gray-600 border border-gray-500 rounded text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">Dependencies</label>
                      <select
                        multiple
                        value={task.dependencies}
                        onChange={(e) => {
                          const selected = Array.from(e.target.selectedOptions, option => option.value);
                          handleTaskChange(index, 'dependencies', selected);
                        }}
                        className="w-full px-2 py-1 bg-gray-600 border border-gray-500 rounded text-white text-sm"
                      >
                        {formData.resource_allocation_inputs.tasks
                          .filter(t => t.id !== task.id)
                          .map(t => (
                            <option key={t.id} value={t.id}>{t.name}</option>
                          ))
                        }
                      </select>
                    </div>
                  </div>
                  <button
                    onClick={() => removeTask(index)}
                    className="flex items-center px-2 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                  >
                    <Minus className="h-3 w-3 mr-1" />
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Project Data Collection</h2>
        <p className="text-gray-400">Please provide all the necessary information for comprehensive project analysis</p>
      </div>

      {/* Section Navigation */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeSection === section.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <Icon className="h-4 w-4 mr-2" />
              {section.title}
            </button>
          );
        })}
      </div>

      {/* Form Content */}
      <div className="bg-gray-800 rounded-lg p-8">
        {renderSection()}
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center">
        <button
          onClick={() => setActiveSection(Math.max(0, activeSection - 1))}
          disabled={activeSection === 0}
          className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Previous
        </button>
        
        <span className="text-gray-400">
          Step {activeSection + 1} of {sections.length}
        </span>
        
        {activeSection < sections.length - 1 ? (
          <button
            onClick={() => setActiveSection(Math.min(sections.length - 1, activeSection + 1))}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Next
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            className="px-8 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold"
          >
            Analyze Project
          </button>
        )}
      </div>
    </div>
  );
};

export default DataCollection;