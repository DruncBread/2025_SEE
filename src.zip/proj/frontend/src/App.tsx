import React, { useState } from 'react';
import DataCollection from './components/DataCollection';
import ResultsDashboard from './components/ResultsDashboard';
import Navigation from './components/Navigation';

export interface ProjectData {
  projectName: string;
  cocomo: {
    sloc: number;
    project_class: 'O' | 'S' | 'E';
    eaf?: number;
  };
  discount_rate: number;
  resource_allocation_inputs: {
    tasks: {
      id: string;
      name: string;
      duration: number;
      dependencies: string[];
    }[];
    resource_capacity: {
      developers: number;
      testers: number;
    };
  };
}

export interface AnalysisResults {
  cocomo: {
    D: number;
    E: number;
    P: number;
    cost_USD: number;
    input_parameters: {
      eaf: number;
      project_class: 'O' | 'S' | 'E';
      sloc: number;
    };
  };
  financial: {
    budgetTracking: {
      actual: number[];
      planned: number[];
      variance: number[];
    };
    cashFlowAnalysis: {
      period: string;
      cashFlow: number;
    }[];
    discount_rate: number;
    irr: number;
    npv: number;
    payback_period: number;
    roi: number;
  };
  resource_schedule: {
    criticalPath: string[];
    optimization: {
      current: { cost: number; duration: number };
      optimized: { cost: number; duration: number };
      savings: { cost: number; time: number };
    };
    projectDuration: number;
    resourceUtilization: {
      name: string;
      utilization: number;
    }[];
    totalCost: number;
  };
  risk_analysis: {
    monteCarloResults: {
      expectedValue: number;
      standardDeviation: number;
      confidenceInterval: {
        lower: number;
        upper: number;
      };
      distribution: {
        frequency: number;
        value: number;
      }[];
    };
    riskMatrix: {
      name: string;
      probability: number;
      impact: number;
      score: number;
    }[];
    sensitivityAnalysis: {
      variable: string;
      impact: number;
    }[];
    totalRiskScore: number;
  };
}

function App() {
  const [currentStep, setCurrentStep] = useState<'input' | 'results'>('input');
  const [projectData, setProjectData] = useState<ProjectData | null>(null);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResults | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDataSubmit = async (data: ProjectData) => {
    setIsProcessing(true);
    setProjectData(data);

    const { projectName, ...dataToSend } = data;

    try {
      console.log(data);
      const response = await fetch(`http://59.65.191.49:9090/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSend)
      });

      if (!response.ok) {
        throw new Error('Backend error: ' + response.statusText);
      }

      const result: AnalysisResults = await response.json();
      console.log(result);
      setAnalysisResults(result);
      setCurrentStep('results');
    } catch (error) {
      console.error('Error processing data:', error);
      // Optionally handle UI error state here
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBackToInput = () => {
    setCurrentStep('input');
    setAnalysisResults(null);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navigation
        currentStep={currentStep}
        onBackToInput={handleBackToInput}
        projectName={projectData?.projectName}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isProcessing && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-gray-800 p-8 rounded-lg text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <h3 className="text-xl font-semibold mb-2">Processing Your Data</h3>
              <p className="text-gray-400">Analyzing project parameters and generating insights...</p>
            </div>
          </div>
        )}

        {currentStep === 'input' && (
          <DataCollection onSubmit={handleDataSubmit} />
        )}

        {currentStep === 'results' && analysisResults && projectData && (
          <ResultsDashboard
            results={analysisResults}
            projectData={projectData}
          />
        )}
      </main>
    </div>
  );
}

export default App;
