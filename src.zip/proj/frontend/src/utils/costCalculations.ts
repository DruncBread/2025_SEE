export interface COCOMOResult {
  effort: number;
  duration: number;
  teamSize: number;
}

export interface FunctionPointsInput {
  inputs: number;
  outputs: number;
  inquiries: number;
  files: number;
  interfaces: number;
}

export interface FunctionPointsResult {
  totalFP: number;
  estimatedEffort: number;
  productivity: number;
}

export interface ExpertJudgmentResult {
  finalEstimate: number;
  confidence: number;
  standardDeviation: number;
  range: { min: number; max: number };
}

export interface RegressionResult {
  effort: number;
  confidence: number;
  rSquared: number;
}

export const calculateCOCOMO = (kloc: number, complexity: 'simple' | 'medium' | 'complex'): COCOMOResult => {
  const coefficients = {
    simple: { a: 2.4, b: 1.05, c: 2.5, d: 0.38 },
    medium: { a: 3.0, b: 1.12, c: 2.5, d: 0.35 },
    complex: { a: 3.6, b: 1.20, c: 2.5, d: 0.32 }
  };

  const coeff = coefficients[complexity];
  const effort = coeff.a * Math.pow(kloc, coeff.b);
  const duration = coeff.c * Math.pow(effort, coeff.d);
  const teamSize = effort / duration;

  return {
    effort: Math.round(effort * 10) / 10,
    duration: Math.round(duration * 10) / 10,
    teamSize: Math.round(teamSize * 10) / 10
  };
};

export const calculateFunctionPoints = (input: FunctionPointsInput): FunctionPointsResult => {
  const weights = {
    inputs: 4,
    outputs: 5,
    inquiries: 4,
    files: 10,
    interfaces: 7
  };

  const totalFP = 
    input.inputs * weights.inputs +
    input.outputs * weights.outputs +
    input.inquiries * weights.inquiries +
    input.files * weights.files +
    input.interfaces * weights.interfaces;

  // Assuming 20 FP per person-month (industry average)
  const estimatedEffort = totalFP / 20;
  const productivity = totalFP / estimatedEffort;

  return {
    totalFP,
    estimatedEffort: Math.round(estimatedEffort * 10) / 10,
    productivity: Math.round(productivity * 10) / 10
  };
};

export const calculateExpertJudgment = (estimates: number[]): ExpertJudgmentResult => {
  const sortedEstimates = [...estimates].sort((a, b) => a - b);
  const mean = estimates.reduce((sum, est) => sum + est, 0) / estimates.length;
  
  // Calculate standard deviation
  const variance = estimates.reduce((sum, est) => sum + Math.pow(est - mean, 2), 0) / estimates.length;
  const standardDeviation = Math.sqrt(variance);
  
  // Use weighted average (Delphi method) - higher weight for middle estimates
  const weights = [0.1, 0.2, 0.4, 0.2, 0.1]; // Assuming 5 estimates
  const finalEstimate = sortedEstimates.reduce((sum, est, index) => 
    sum + est * (weights[index] || 0.2), 0
  );
  
  // Confidence based on consistency (lower deviation = higher confidence)
  const confidence = Math.max(0, 100 - (standardDeviation / mean) * 100);
  
  return {
    finalEstimate: Math.round(finalEstimate * 10) / 10,
    confidence: Math.round(confidence * 10) / 10,
    standardDeviation: Math.round(standardDeviation * 10) / 10,
    range: {
      min: Math.round(Math.min(...estimates) * 10) / 10,
      max: Math.round(Math.max(...estimates) * 10) / 10
    }
  };
};

export const calculateRegression = (kloc: number, teamSize: number, duration: number): RegressionResult => {
  // Simplified regression model: Effort = a + b*KLOC + c*TeamSize + d*Duration
  // Coefficients based on historical data (simplified)
  const a = 10;
  const b = 2.5;
  const c = 3.2;
  const d = 1.8;
  
  const effort = a + b * kloc + c * teamSize + d * duration;
  
  // Simplified confidence and R-squared calculation
  const confidence = 85 + Math.random() * 10; // Simulated
  const rSquared = 0.75 + Math.random() * 0.2; // Simulated
  
  return {
    effort: Math.round(effort * 10) / 10,
    confidence: Math.round(confidence * 10) / 10,
    rSquared: Math.round(rSquared * 1000) / 1000
  };
};