export const calculateROI = (
  initialInvestment: number,
  revenues: number[],
  costs: number[]
): number => {
  const totalRevenue = revenues.reduce((sum, rev) => sum + rev, 0);
  const totalCosts = costs.reduce((sum, cost) => sum + cost, 0);
  const totalInvestment = initialInvestment + totalCosts;
  
  return ((totalRevenue - totalInvestment) / totalInvestment) * 100;
};

export const calculateNPV = (
  initialInvestment: number,
  revenues: number[],
  costs: number[],
  discountRate: number
): number => {
  let npv = -initialInvestment;
  
  for (let i = 0; i < revenues.length; i++) {
    const netCashFlow = revenues[i] - costs[i];
    const presentValue = netCashFlow / Math.pow(1 + discountRate, i + 1);
    npv += presentValue;
  }
  
  return Math.round(npv);
};

export const calculateIRR = (
  initialInvestment: number,
  revenues: number[],
  costs: number[]
): number => {
  // Simplified IRR calculation using Newton-Raphson method
  let irr = 0.1; // Initial guess
  let precision = 0.0001;
  let maxIterations = 100;
  
  for (let i = 0; i < maxIterations; i++) {
    let npv = -initialInvestment;
    let dnpv = 0;
    
    for (let j = 0; j < revenues.length; j++) {
      const netCashFlow = revenues[j] - costs[j];
      const period = j + 1;
      npv += netCashFlow / Math.pow(1 + irr, period);
      dnpv += -period * netCashFlow / Math.pow(1 + irr, period + 1);
    }
    
    if (Math.abs(npv) < precision) break;
    irr = irr - npv / dnpv;
  }
  
  return Math.max(0, irr);
};

export const calculatePaybackPeriod = (
  initialInvestment: number,
  revenues: number[],
  costs: number[]
): number => {
  let cumulativeCashFlow = -initialInvestment;
  
  for (let i = 0; i < revenues.length; i++) {
    const netCashFlow = revenues[i] - costs[i];
    cumulativeCashFlow += netCashFlow;
    
    if (cumulativeCashFlow >= 0) {
      // Calculate fractional year
      const previousCumulative = cumulativeCashFlow - netCashFlow;
      const fraction = Math.abs(previousCumulative) / netCashFlow;
      return i + 1 - fraction;
    }
  }
  
  return revenues.length; // If payback period exceeds project duration
};