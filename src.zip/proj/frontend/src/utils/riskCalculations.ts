export interface SensitivityParams {
  baseCase: number;
  variables: Array<{
    name: string;
    min: number;
    max: number;
  }>;
}

export interface SensitivityResult {
  variable: string;
  impact: number;
  scenarios: Array<{
    change: number;
    value: number;
  }>;
}

export interface MonteCarloParams {
  iterations: number;
  baseValue: number;
  volatility: number;
}

export interface MonteCarloResult {
  expectedValue: number;
  standardDeviation: number;
  confidenceInterval: {
    lower: number;
    upper: number;
  };
  bins: string[];
  frequencies: number[];
}

export interface Risk {
  id: string;
  name: string;
  probability: number;
  impact: number;
  category: string;
}

export const performSensitivityAnalysis = (params: SensitivityParams): SensitivityResult[] => {
  return params.variables.map(variable => {
    const scenarios = [];
    const changes = [-30, -20, -10, 0, 10, 20, 30];
    
    for (const change of changes) {
      const multiplier = 1 + (change / 100);
      const value = params.baseCase * multiplier;
      scenarios.push({ change, value });
    }
    
    // Calculate impact as the range of outcomes
    const maxValue = Math.max(...scenarios.map(s => s.value));
    const minValue = Math.min(...scenarios.map(s => s.value));
    const impact = ((maxValue - minValue) / params.baseCase) * 100;
    
    return {
      variable: variable.name,
      impact: Math.round(impact * 10) / 10,
      scenarios
    };
  });
};

export const generateMonteCarloSimulation = (params: MonteCarloParams): MonteCarloResult => {
  const results: number[] = [];
  
  // Generate random outcomes using normal distribution approximation
  for (let i = 0; i < params.iterations; i++) {
    // Box-Muller transformation for normal distribution
    const u1 = Math.random();
    const u2 = Math.random();
    const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    
    const outcome = params.baseValue + (params.baseValue * params.volatility * z0);
    results.push(outcome);
  }
  
  // Calculate statistics
  const expectedValue = results.reduce((sum, val) => sum + val, 0) / results.length;
  const variance = results.reduce((sum, val) => sum + Math.pow(val - expectedValue, 2), 0) / results.length;
  const standardDeviation = Math.sqrt(variance);
  
  // Calculate confidence interval (95%)
  const sortedResults = [...results].sort((a, b) => a - b);
  const lowerIndex = Math.floor(params.iterations * 0.025);
  const upperIndex = Math.floor(params.iterations * 0.975);
  
  // Create histogram
  const numBins = 20;
  const minValue = Math.min(...results);
  const maxValue = Math.max(...results);
  const binWidth = (maxValue - minValue) / numBins;
  
  const bins: string[] = [];
  const frequencies: number[] = [];
  
  for (let i = 0; i < numBins; i++) {
    const binStart = minValue + i * binWidth;
    const binEnd = binStart + binWidth;
    bins.push(`${Math.round(binStart / 1000)}k`);
    
    const count = results.filter(val => val >= binStart && val < binEnd).length;
    frequencies.push(count);
  }
  
  return {
    expectedValue: Math.round(expectedValue),
    standardDeviation: Math.round(standardDeviation),
    confidenceInterval: {
      lower: Math.round(sortedResults[lowerIndex]),
      upper: Math.round(sortedResults[upperIndex])
    },
    bins,
    frequencies
  };
};

export const createDecisionTree = (risks: Risk[]) => {
  // Simplified decision tree structure
  const totalRiskScore = risks.reduce((sum, risk) => sum + (risk.probability * risk.impact), 0);
  const averageRiskScore = totalRiskScore / risks.length;
  
  const decisions = [
    {
      name: 'Proceed with Current Plan',
      probability: 0.6,
      outcome: averageRiskScore > 5 ? 'High Risk' : 'Medium Risk',
      expectedValue: 1000000 - (totalRiskScore * 50000)
    },
    {
      name: 'Implement Risk Mitigation',
      probability: 0.8,
      outcome: 'Low Risk',
      expectedValue: 900000 - (totalRiskScore * 20000)
    },
    {
      name: 'Delay Project',
      probability: 0.9,
      outcome: 'Very Low Risk',
      expectedValue: 800000 - (totalRiskScore * 10000)
    }
  ];
  
  return decisions;
};